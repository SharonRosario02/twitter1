import React from 'react'
import '../pages.css'

function More() {
    return (
        <div className='page'>
            <h2 className='pageTitle'>Welcome to More page</h2>
        </div>
    )
}

export default More