import React from 'react'
import './Widgets.css'

const Widgets = () => {
  return (
    <div> <h1> Widgets </h1>
    </div>
  )
}

export default Widgets;