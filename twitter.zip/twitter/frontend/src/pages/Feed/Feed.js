import React from 'react'
import './Feed.css'
import TweetBox from './TweetBox/TweetBox';

const Feed = () => {
  return (
     <>
      
      <TweetBox/>
      </>
  )
}

export default Feed;