import React from 'react'
import '../pages.css'

function Profile() {
    return (
        <div className='page'>
            <h2 className='pageTitle'>Welcome to Prifile page</h2>
        </div>
    )
}

export default Profile