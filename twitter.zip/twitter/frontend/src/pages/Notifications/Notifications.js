import React from 'react'
import '../pages.css'

function Notifications() {
    return (
        <div className='page'>
            <h2 className='pageTitle'>Welcome to Notifications page</h2>
        </div>
    )
}

export default Notifications